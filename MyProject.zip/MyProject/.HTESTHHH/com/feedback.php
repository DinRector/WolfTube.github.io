<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>отзиви мне</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
        }

        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 600px;
            text-align: center;
        }

        h1 {
            color: #333;
            margin-bottom: 20px;
            font-size: 24px;
            opacity: 1;
            transition: opacity 1s ease-in-out;
        }

        input[type="text"], textarea {
            width: 100%;
            padding: 12px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
            box-sizing: border-box;
        }

        textarea {
            resize: vertical;
            height: 120px;
        }

        button {
            background-color: #28a745;
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            width: 100%;
        }

        button:hover {
            background-color: #218838;
        }

        .message {
            margin-top: 20px;
            font-size: 14px;
            color: #28a745;
        }

        .comments {
            margin-top: 30px;
            text-align: left;
        }

        .comment {
            background-color: #f1f1f1;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 10px;
        }

        .comment strong {
            color: #333;
        }

        @media (max-width: 600px) {
            body {
                padding: 10px;
            }

            .container {
                padding: 15px;
            }

            h1 {
                font-size: 20px;
            }

            input[type="text"], textarea {
                padding: 10px;
                font-size: 14px;
            }

            textarea {
                height: 100px;
            }

            button {
                padding: 10px 20px;
                font-size: 14px;
            }

            .message {
                font-size: 12px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 id="animatedTitle">Оставьте комментарий</h1>
        <input type="text" id="name" placeholder="Ваше имя">
        <textarea id="comment" placeholder="Ваш комментарий"></textarea>
        <button onclick="submitComment()">Отправить</button>
        <p class="message" id="message"></p>

        <!-- Блок для отображения комментариев -->
        <div class="comments" id="comments">
            <!-- Комментарии будут загружены сюда -->
        </div>
    </div>

    <script>
        // Массив с текстами для заголовка
        const titles = [
            "милана огурец",
            "Оставьте комментарий",
            "1488",
            "Мы ценим ваше мнение",
            "Не ценим*",
            "Милана ест кактус"
        ];

        let currentIndex = 0;
        const titleElement = document.getElementById("animatedTitle");

        // Функция для смены заголовка
        function changeTitle() {
            titleElement.style.opacity = 0; // Плавное исчезновение

            setTimeout(() => {
                currentIndex = (currentIndex + 1) % titles.length; // Переход к следующему заголовку
                titleElement.textContent = titles[currentIndex];
                titleElement.style.opacity = 1; // Плавное появление
            }, 1000); // Задержка для плавного перехода
        }

        // Меняем заголовок каждые 5 секунд
        setInterval(changeTitle, 5000);

        // Функция для отправки комментария
        function submitComment() {
            const name = document.getElementById("name").value;
            const comment = document.getElementById("comment").value;

            if (!name || !comment) {
                alert("Пожалуйста, заполните все поля!");
                return;
            }

            // Отправляем данные на сервер
            fetch("save_comment.php", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({ name, comment }),
            })
            .then(response => response.text())
            .then(data => {
                document.getElementById("message").textContent = data;
                document.getElementById("name").value = ""; // Очищаем поле имени
                document.getElementById("comment").value = ""; // Очищаем поле комментария
                loadComments(); // Обновляем список комментариев
            })
            .catch(error => {
                console.error("Ошибка:", error);
                document.getElementById("message").textContent = "Произошла ошибка при отправке комментария.";
            });
        }

        // Функция для загрузки комментариев
        function loadComments() {
            fetch("get_comments.php")
                .then(response => response.json())
                .then(data => {
                    const commentsContainer = document.getElementById("comments");
                    commentsContainer.innerHTML = ""; // Очищаем контейнер

                    data.forEach(comment => {
                        const commentElement = document.createElement("div");
                        commentElement.className = "comment";
                        commentElement.innerHTML = `<strong>${comment.name}</strong>: ${comment.comment}`;
                        commentsContainer.appendChild(commentElement);
                    });
                })
                .catch(error => {
                    console.error("Ошибка при загрузке комментариев:", error);
                });
        }

        // Загружаем комментарии при загрузке страницы
        window.onload = loadComments;
    </script>
</body>
</html>