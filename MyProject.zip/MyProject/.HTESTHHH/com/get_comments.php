<?php
// Проверяем, существует ли файл с комментариями
if (file_exists('comments.json')) {
    // Читаем и возвращаем комментарии в формате JSON
    $comments = file_get_contents('comments.json');
    echo $comments;
} else {
    echo json_encode([]); // Возвращаем пустой массив, если файла нет
}
?>