<?php

const DB_HOST = 'localhost';
const DB_NAME = 'f1083614_db';
const DB_USERNAME = 'f1083614_db';
const DB_PASSWORD = 'atriuxxipe';