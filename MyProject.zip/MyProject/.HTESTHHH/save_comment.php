<?php
// Проверяем, что запрос был отправлен методом POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Получаем данные из тела запроса
    $data = json_decode(file_get_contents('php://input'), true);

    // Проверяем, что данные не пустые
    if (isset($data['name']) && isset($data['comment'])) {
        $name = htmlspecialchars($data['name']); // Защита от XSS
        $comment = htmlspecialchars($data['comment']); // Защита от XSS

        // Формируем строку для записи в файл
        $commentData = "Имя: $name\nКомментарий: $comment\n---------------------------\n";

        // Записываем данные в файл
        if (file_put_contents('comments.txt', $commentData, FILE_APPEND)) {
            echo "Комментарий успешно отправлен!";
        } else {
            echo "Ошибка при отправке комментария.";
        }
    } else {
        echo "Неверные данные.";
    }
} else {
    echo "Метод запроса не поддерживается.";
}
?>